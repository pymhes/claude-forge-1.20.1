package com.claudeai.mod.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class ClaudeConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<String> CLAUDE_API_KEY;
    public static final ForgeConfigSpec.IntValue CHAT_RADIUS;
    public static final ForgeConfigSpec.BooleanValue AUTO_DEFEND;

    static {
        Pair<ClaudeConfig, ForgeConfigSpec> specPair = new ForgeConfigSpec.Builder().configure(ClaudeConfig::new);
        SPEC = specPair.getRight();
    }

    private ClaudeConfig(ForgeConfigSpec.Builder builder) {
        builder.comment("Claude AI Companion Configuration").push("general");

        CLAUDE_API_KEY = builder
                .comment("Your Anthropic API Key. Get one from https://console.anthropic.com/")
                .define("apiKey", "YOUR_API_KEY_HERE");

        CHAT_RADIUS = builder
                .comment("Radius in blocks within which Claude listens to player chat")
                .defineInRange("chatRadius", 20, 5, 100);

        AUTO_DEFEND = builder
                .comment("Whether Claude should automatically attack hostile mobs")
                .define("autoDefend", true);

        builder.pop();
    }
}
