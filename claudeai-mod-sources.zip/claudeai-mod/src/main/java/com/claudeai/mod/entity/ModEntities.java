package com.claudeai.mod.entity;

import com.claudeai.mod.ClaudeAIMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ClaudeAIMod.MOD_ID);

    public static final RegistryObject<EntityType<ClaudeEntity>> CLAUDE_ENTITY =
            ENTITY_TYPES.register("claude_companion",
                    () -> EntityType.Builder.<ClaudeEntity>of(ClaudeEntity::new, MobCategory.MISC)
                            .sized(0.6F, 1.8F)
                            .clientTrackingRange(10)
                            .build("claude_companion"));
}
