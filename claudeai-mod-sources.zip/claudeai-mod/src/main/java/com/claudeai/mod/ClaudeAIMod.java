package com.claudeai.mod;

import com.claudeai.mod.config.ClaudeConfig;
import com.claudeai.mod.entity.ClaudeEntity;
import com.claudeai.mod.entity.ModEntities;
import com.claudeai.mod.network.ModNetwork;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(ClaudeAIMod.MOD_ID)
public class ClaudeAIMod {
    public static final String MOD_ID = "claudeai";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public ClaudeAIMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModEntities.ENTITY_TYPES.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::onEntityAttributeCreation);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ClaudeConfig.SPEC, "claudeai-common.toml");

        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        ModNetwork.register();
        LOGGER.info("Claude AI Mod loaded successfully!");
    }

    @SubscribeEvent
    public void onEntityAttributeCreation(EntityAttributeCreationEvent event) {
        event.put(ModEntities.CLAUDE_ENTITY.get(), ClaudeEntity.createAttributes().build());
    }
}
