package com.claudeai.mod;

import com.claudeai.mod.config.ClaudeConfig;
import com.claudeai.mod.entity.ClaudeEntity;
import com.claudeai.mod.entity.ModEntities;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = ClaudeAIMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ChatEventHandler {

    @SubscribeEvent
    public static void onServerChat(ServerChatEvent event) {
        ServerPlayer player = event.getPlayer();
        String message = event.getMessage().getString();

        if (!(player.level() instanceof ServerLevel serverLevel)) return;

        int radius = ClaudeConfig.CHAT_RADIUS.get();

        // Find nearest Claude entity within chat radius
        List<ClaudeEntity> nearbyClauds = serverLevel.getEntitiesOfClass(
                ClaudeEntity.class,
                player.getBoundingBox().inflate(radius)
        );

        if (nearbyClauds.isEmpty()) return;

        // Find the closest one
        ClaudeEntity closest = nearbyClauds.stream()
                .min((a, b) -> Double.compare(
                        a.distanceToSqr(player),
                        b.distanceToSqr(player)
                ))
                .orElse(null);

        if (closest != null) {
            closest.receivePlayerMessage(player, message);
        }
    }
}
