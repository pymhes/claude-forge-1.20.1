package com.claudeai.mod.ai;

import com.claudeai.mod.entity.ClaudeEntity;
import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;

import java.util.*;

public class TaskManager {

    private final ClaudeEntity entity;
    private String activeTaskId = "";
    private int taskTimer = 0;
    private int taskDuration = 0;
    private JsonObject taskParams = new JsonObject();
    private Player taskOwner = null;

    // Task durations in ticks
    private static final Map<String, Integer> TASK_DURATIONS = Map.of(
            "mine_wood", 200,
            "mine_stone", 200,
            "mine_ores", 300,
            "collect_items", 100,
            "build_shelter", 600,
            "farm_food", 250,
            "explore", 400,
            "guard", 600
    );

    public TaskManager(ClaudeEntity entity) {
        this.entity = entity;
    }

    public void startTask(Player player, String taskId, JsonObject params) {
        this.activeTaskId = taskId;
        this.taskParams = params;
        this.taskOwner = player;
        this.taskTimer = 0;
        this.taskDuration = TASK_DURATIONS.getOrDefault(taskId, 200);
        entity.setCurrentTask(taskId);

        switch (taskId) {
            case "follow_player" -> startFollowTask(player);
            case "idle" -> stopCurrentTask();
            case "mine_wood" -> startMineWoodTask(player);
            case "mine_stone" -> startMineStoneTask(player);
            case "mine_ores" -> startMineOresTask(player);
            case "collect_items" -> startCollectTask(player);
            case "guard" -> startGuardTask(player);
            case "explore" -> startExploreTask(player);
            case "farm_food" -> startFarmTask(player);
            default -> entity.sendMessageToPlayer(player, "Görevi başlatıyorum: " + taskId);
        }
    }

    public void tick() {
        if (activeTaskId.isEmpty()) return;

        taskTimer++;

        switch (activeTaskId) {
            case "mine_wood" -> tickMineWood();
            case "mine_stone" -> tickMineStone();
            case "mine_ores" -> tickMineOres();
            case "collect_items" -> tickCollectItems();
            case "guard" -> tickGuard();
            case "explore" -> tickExplore();
            case "farm_food" -> tickFarm();
        }

        if (taskDuration > 0 && taskTimer >= taskDuration) {
            completeTask();
        }
    }

    private void startFollowTask(Player player) {
        entity.setCurrentTask("follow_player");
        entity.sendMessageToPlayer(player, "Seni takip ediyorum! Yanından ayrılmayacağım.");
        // Continuous follow - handled by entity goals
    }

    private void startMineWoodTask(Player player) {
        entity.sendMessageToPlayer(player, "§aYakınlarda ağaç arıyorum ve kesmeye başlıyorum...");
        findAndMoveToBlock(player, Arrays.asList(
                Blocks.OAK_LOG, Blocks.BIRCH_LOG, Blocks.SPRUCE_LOG,
                Blocks.JUNGLE_LOG, Blocks.ACACIA_LOG, Blocks.DARK_OAK_LOG,
                Blocks.MANGROVE_LOG, Blocks.CHERRY_LOG
        ));
    }

    private void tickMineWood() {
        Level level = entity.level();
        BlockPos entityPos = entity.blockPosition();

        // Search for logs nearby
        for (int x = -8; x <= 8; x++) {
            for (int y = -3; y <= 5; y++) {
                for (int z = -8; z <= 8; z++) {
                    BlockPos pos = entityPos.offset(x, y, z);
                    Block block = level.getBlockState(pos).getBlock();
                    if (isWoodLog(block)) {
                        // Move toward and mine
                        entity.getNavigation().moveTo(pos.getX(), pos.getY(), pos.getZ(), 1.0);
                        if (entity.distanceToSqr(pos.getX(), pos.getY(), pos.getZ()) < 4.0) {
                            level.destroyBlock(pos, true);
                            if (taskOwner != null) {
                                entity.sendMessageToPlayer(taskOwner, "§7[Görev] Bir ağaç kestim!");
                            }
                        }
                        return;
                    }
                }
            }
        }
    }

    private boolean isWoodLog(Block block) {
        return block == Blocks.OAK_LOG || block == Blocks.BIRCH_LOG ||
                block == Blocks.SPRUCE_LOG || block == Blocks.JUNGLE_LOG ||
                block == Blocks.ACACIA_LOG || block == Blocks.DARK_OAK_LOG ||
                block == Blocks.MANGROVE_LOG || block == Blocks.CHERRY_LOG;
    }

    private void startMineStoneTask(Player player) {
        entity.sendMessageToPlayer(player, "§aTaş aramaya başlıyorum...");
    }

    private void tickMineStone() {
        Level level = entity.level();
        BlockPos entityPos = entity.blockPosition();

        for (int x = -6; x <= 6; x++) {
            for (int y = -3; y <= 3; y++) {
                for (int z = -6; z <= 6; z++) {
                    BlockPos pos = entityPos.offset(x, y, z);
                    Block block = level.getBlockState(pos).getBlock();
                    if (block == Blocks.STONE || block == Blocks.COBBLESTONE ||
                            block == Blocks.STONE_BRICKS) {
                        entity.getNavigation().moveTo(pos.getX(), pos.getY(), pos.getZ(), 1.0);
                        if (entity.distanceToSqr(pos.getX(), pos.getY(), pos.getZ()) < 4.0) {
                            level.destroyBlock(pos, true);
                            if (taskOwner != null && taskTimer % 40 == 0) {
                                entity.sendMessageToPlayer(taskOwner, "§7[Görev] Taş kazıyorum...");
                            }
                        }
                        return;
                    }
                }
            }
        }
    }

    private void startMineOresTask(Player player) {
        entity.sendMessageToPlayer(player, "§aMaden arıyorum! Kömür, demir veya daha değerli madenleri bulacağım...");
    }

    private void tickMineOres() {
        Level level = entity.level();
        BlockPos entityPos = entity.blockPosition();

        List<Block> ores = Arrays.asList(
                Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE,
                Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
                Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE,
                Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE,
                Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
                Blocks.LAPIS_ORE, Blocks.REDSTONE_ORE
        );

        for (int x = -10; x <= 10; x++) {
            for (int y = -5; y <= 5; y++) {
                for (int z = -10; z <= 10; z++) {
                    BlockPos pos = entityPos.offset(x, y, z);
                    Block block = level.getBlockState(pos).getBlock();
                    if (ores.contains(block)) {
                        entity.getNavigation().moveTo(pos.getX(), pos.getY(), pos.getZ(), 1.0);
                        if (entity.distanceToSqr(pos.getX(), pos.getY(), pos.getZ()) < 4.0) {
                            level.destroyBlock(pos, true);
                            if (taskOwner != null) {
                                String oreName = block.getName().getString();
                                entity.sendMessageToPlayer(taskOwner, "§6[Görev] §f" + oreName + " buldum ve kazıyorum!");
                            }
                        }
                        return;
                    }
                }
            }
        }
    }

    private void startCollectTask(Player player) {
        entity.sendMessageToPlayer(player, "§aYerde duran eşyaları topluyorum!");
    }

    private void tickCollectItems() {
        Level level = entity.level();
        List<ItemEntity> items = level.getEntitiesOfClass(ItemEntity.class,
                new AABB(entity.blockPosition()).inflate(16));

        if (!items.isEmpty()) {
            ItemEntity nearest = items.stream()
                    .min(Comparator.comparingDouble(item -> item.distanceToSqr(entity)))
                    .orElse(null);

            if (nearest != null) {
                entity.getNavigation().moveTo(nearest, 1.2);
                if (entity.distanceToSqr(nearest) < 2.0) {
                    ItemStack stack = nearest.getItem().copy();
                    nearest.discard();
                    if (taskOwner != null) {
                        entity.sendMessageToPlayer(taskOwner, "§7[Görev] §f" + stack.getHoverName().getString() + " topladım!");
                    }
                }
            }
        }
    }

    private void startGuardTask(Player player) {
        entity.sendMessageToPlayer(player, "§aNöbet tutuyorum! Yakında düşman varsa saldırırım.");
    }

    private void tickGuard() {
        // The entity's combat goals handle mob targeting automatically
        if (taskOwner != null && taskTimer % 100 == 0) {
            entity.sendMessageToPlayer(taskOwner, "§7[Nöbet] Bölgeyi gözlemliyorum...");
        }
    }

    private void startExploreTask(Player player) {
        entity.sendMessageToPlayer(player, "§aÇevreyi keşfediyorum! Geri döndüğümde rapor vereceğim.");

        // Move to a random nearby position
        Random random = new Random();
        int dx = random.nextInt(32) - 16;
        int dz = random.nextInt(32) - 16;
        BlockPos target = entity.blockPosition().offset(dx, 0, dz);
        entity.getNavigation().moveTo(target.getX(), target.getY(), target.getZ(), 1.0);
    }

    private void tickExplore() {
        if (taskTimer % 80 == 0 && taskOwner != null) {
            BlockPos pos = entity.blockPosition();
            entity.sendMessageToPlayer(taskOwner,
                    "§7[Keşif] §fŞu an " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() +
                            " koordinatlarındayım. Çevreye bakıyorum...");
        }
    }

    private void startFarmTask(Player player) {
        entity.sendMessageToPlayer(player, "§aYiyecek topluyorum! Yetişmiş ürün arıyorum...");
    }

    private void tickFarm() {
        Level level = entity.level();
        BlockPos entityPos = entity.blockPosition();

        List<Block> harvestable = Arrays.asList(
                Blocks.WHEAT, Blocks.CARROTS, Blocks.POTATOES,
                Blocks.BEETROOTS, Blocks.MELON, Blocks.PUMPKIN,
                Blocks.SUGAR_CANE, Blocks.SWEET_BERRY_BUSH
        );

        for (int x = -12; x <= 12; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -12; z <= 12; z++) {
                    BlockPos pos = entityPos.offset(x, y, z);
                    Block block = level.getBlockState(pos).getBlock();
                    if (harvestable.contains(block)) {
                        entity.getNavigation().moveTo(pos.getX(), pos.getY(), pos.getZ(), 1.0);
                        if (entity.distanceToSqr(pos.getX(), pos.getY(), pos.getZ()) < 4.0) {
                            level.destroyBlock(pos, true);
                            if (taskOwner != null) {
                                entity.sendMessageToPlayer(taskOwner, "§7[Tarım] §f" +
                                        block.getName().getString() + " topladım!");
                            }
                        }
                        return;
                    }
                }
            }
        }
    }

    private void findAndMoveToBlock(Player player, List<Block> targetBlocks) {
        Level level = entity.level();
        BlockPos entityPos = entity.blockPosition();

        for (int radius = 1; radius <= 15; radius++) {
            for (int x = -radius; x <= radius; x++) {
                for (int y = -3; y <= 5; y++) {
                    for (int z = -radius; z <= radius; z++) {
                        BlockPos pos = entityPos.offset(x, y, z);
                        if (targetBlocks.contains(level.getBlockState(pos).getBlock())) {
                            entity.getNavigation().moveTo(pos.getX(), pos.getY(), pos.getZ(), 1.0);
                            return;
                        }
                    }
                }
            }
        }

        entity.sendMessageToPlayer(player, "§cYakınlarda hedef bulamadım!");
    }

    public void stopCurrentTask() {
        if (!activeTaskId.isEmpty() && taskOwner != null) {
            entity.sendMessageToPlayer(taskOwner, "Görev durduruldu. Hazır ve boştayım!");
        }
        activeTaskId = "";
        taskTimer = 0;
        entity.setCurrentTask("");
        entity.getNavigation().stop();
    }

    private void completeTask() {
        String completedTask = activeTaskId;
        activeTaskId = "";
        taskTimer = 0;
        entity.setCurrentTask("");

        if (taskOwner != null) {
            entity.sendMessageToPlayer(taskOwner, "§a✓ Görev tamamlandı: §f" + getTaskDisplayName(completedTask) + "!");
        }
    }

    private String getTaskDisplayName(String taskId) {
        return switch (taskId) {
            case "mine_wood" -> "Ağaç kesme";
            case "mine_stone" -> "Taş kazma";
            case "mine_ores" -> "Maden kazma";
            case "collect_items" -> "Eşya toplama";
            case "build_shelter" -> "Barınak yapımı";
            case "farm_food" -> "Yiyecek toplama";
            case "explore" -> "Keşif";
            case "guard" -> "Nöbet";
            default -> taskId;
        };
    }

    public boolean isActive() {
        return !activeTaskId.isEmpty();
    }

    public String getActiveTaskId() {
        return activeTaskId;
    }
}
