# 🤖 Claude AI Companion Mod - Minecraft Forge 1.20.1

Bu mod, Minecraft'a **gerçek Claude AI** zekalı bir yoldaş karakter ekler.

## ✨ Özellikler

- 💬 **Çok dilli sohbet** - Oyuncunun dilinde konuşur (Türkçe, İngilizce, Almanca vb.)
- ⚔️ **Görev yönetimi** - Chat'e görev yazınca gerçekten yapar
- 🛡️ **Otomatik savunma** - Düşmanlara karşı kendini korur
- 🧠 **Gerçek Claude AI** - Anthropic'in Claude API'si kullanılır

## 🎮 Görevler

Chat'e şunları yazabilirsiniz:
| Mesaj | Sonuç |
|-------|-------|
| "Ağaç kes" | Yakındaki ağaçları keser |
| "Taş kaz" | Taş blokları kazar |
| "Maden ara" | Değerli madenleri bulur |
| "Eşyaları topla" | Yerdeki itemleri toplar |
| "Çevreyi keşfet" | Alanı keşfeder, rapor verir |
| "Nöbet tut" | Mob'lara karşı koruma sağlar |
| "Yiyecek topla" | Yetişmiş mahsul toplar |
| Herhangi bir soru | Akıllıca cevap verir! |

## 🚀 Kurulum

### Gereksinimler
- Java 17+
- Minecraft 1.20.1
- Forge 47.2.0+
- Anthropic API anahtarı (ücretsiz: https://console.anthropic.com/)

### 1. Projeyi hazırla
```bash
# Forge MDK indir: https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html
# MDK'yı aç, bu projenin dosyalarını üstüne kopyala
```

### 2. Derle
```bash
# Windows:
gradlew.bat build

# Linux/Mac:
./gradlew build
```

JAR dosyası `build/libs/claudeai-mod-1.0.0.jar` konumunda oluşur.

### 3. Kur
JAR dosyasını `.minecraft/mods/` klasörüne kopyala.

### 4. API Anahtarı
Oyun içinde:
```
/claudeai apikey sk-ant-xxxxxxxxxxxxx
```

Ya da config dosyasından: `config/claudeai-common.toml`

## 🎯 Kullanım

1. Oyunu başlat (Forge profiliyle)
2. Dünyaya gir
3. Claude'u çağır: `/claudeai spawn`
4. Chat'e yaz, Claude seni duyar!

## ⚙️ Komutlar

| Komut | Açıklama |
|-------|----------|
| `/claudeai spawn` | Claude'u yanına çağır |
| `/claudeai apikey <key>` | API anahtarını ayarla |
| `/claudeai status` | Mod durumunu göster |
| `/claudeai help` | Yardım menüsü |

## 📁 Proje Yapısı

```
src/main/java/com/claudeai/mod/
├── ClaudeAIMod.java          # Ana mod sınıfı
├── ChatEventHandler.java     # Chat dinleyici
├── ClaudeCommand.java        # /claudeai komutları
├── ai/
│   ├── ClaudeAIBrain.java    # Claude API bağlantısı
│   └── TaskManager.java      # Görev yönetimi
├── config/
│   └── ClaudeConfig.java     # Mod ayarları
├── entity/
│   ├── ClaudeEntity.java     # AI karakter entity
│   └── ModEntities.java      # Entity kaydı
└── network/
    └── ModNetwork.java       # Ağ paketleri
```

## 🔧 Yapı Adımları (Detaylı)

1. [Forge MDK](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html) indir (1.20.1-47.2.0)
2. Zip'i aç → yeni bir klasöre
3. Bu modun `src/` ve `build.gradle` dosyalarını o klasöre kopyala
4. `gradlew build` çalıştır (ilk seferde ~10 dakika sürebilir)
5. `build/libs/` klasöründe `.jar` dosyasını bul
6. Mods klasörüne kopyala!

---
Made with ❤️ by Claude AI
