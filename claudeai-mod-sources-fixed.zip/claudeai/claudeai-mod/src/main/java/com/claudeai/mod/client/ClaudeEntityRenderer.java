package com.claudeai.mod.client;

import com.claudeai.mod.ClaudeAIMod;
import com.claudeai.mod.entity.ClaudeEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ClaudeEntityRenderer extends MobRenderer<ClaudeEntity, ClaudeEntityModel> {

    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(ClaudeAIMod.MOD_ID, "claude_companion"), "main");

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ClaudeAIMod.MOD_ID, "textures/entity/claude_companion.png");

    public ClaudeEntityRenderer(EntityRendererProvider.Context context) {
        super(context, new ClaudeEntityModel(context.bakeLayer(LAYER_LOCATION)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(ClaudeEntity entity) {
        return TEXTURE;
    }

    @Override
    public void render(ClaudeEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}
