package com.claudeai.mod.ai;

import com.claudeai.mod.ClaudeAIMod;
import com.claudeai.mod.config.ClaudeConfig;
import com.claudeai.mod.entity.ClaudeEntity;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.world.entity.player.Player;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CompletableFuture;

public class ClaudeAIBrain {

    private final ClaudeEntity entity;
    private final Gson gson = new Gson();
    private final List<JsonObject> conversationHistory = new ArrayList<>();

    // Kullanım takibi — Haiku: $0.80/1M input, $4.00/1M output token
    // $5 başlangıç kredisi hesaba bağlıdır, yeni key almak sıfırlamaz
    private int inputTokensUsed  = 0;
    private int outputTokensUsed = 0;

    // $5 kredi ile Haiku'da tahmini max token (sadece input hesabıyla ~6.25M)
    // Gerçekte output da tüketir, pratik limit ~4-5M token arası
    private static final double STARTING_CREDIT_USD = 5.0;
    private static final double HAIKU_INPUT_COST_PER_M  = 0.80;
    private static final double HAIKU_OUTPUT_COST_PER_M = 4.00;

    private static final String SYSTEM_PROMPT = """
            You are Claude, an AI companion in Minecraft. You are embodied as a character in the game world.
            You can:
            1. Have conversations with the player in whatever language they speak
            2. Execute tasks in Minecraft (mining, building, farming, exploring, etc.)
            3. Defend yourself against hostile mobs
            4. Report your status and what you're doing
            
            When the player gives you a task, respond with a JSON object like this:
            {
              "type": "task",
              "message": "Your friendly message to player",
              "task": "task_identifier",
              "params": {"key": "value"}
            }
            
            Available task identifiers:
            - "follow_player": Follow the player
            - "mine_wood": Find and chop nearby wood
            - "mine_stone": Mine stone blocks
            - "mine_ores": Find and mine ores
            - "collect_items": Collect nearby dropped items
            - "build_shelter": Build a simple shelter
            - "farm_food": Find and harvest food
            - "explore": Explore the area and report back
            - "guard": Stay in position and guard against mobs
            - "idle": Stop current task and be idle
            - "chat": Just have a conversation (no task)
            
            When just chatting, use:
            {
              "type": "chat",
              "message": "Your message"
            }
            
            Always respond in the same language as the player.
            Be friendly, helpful, and personality-rich like Claude AI.
            Keep responses concise for game use.
            IMPORTANT: Only respond with valid JSON, nothing else.
            """;

    public ClaudeAIBrain(ClaudeEntity entity) {
        this.entity = entity;
    }

    public void processMessage(Player player, String message) {
        String apiKey = ClaudeConfig.CLAUDE_API_KEY.get();

        if (apiKey == null || apiKey.isBlank() || apiKey.equals("YOUR_API_KEY_HERE")) {
            entity.sendMessageToPlayer(player,
                "§c[Claude AI] API anahtarı ayarlanmamış!§r\n" +
                "§f/claudeai apikey <anahtarın> §7komutunu kullan.\n" +
                "§7Anahtar almak için: §bhttps://console.anthropic.com");
            return;
        }

        // Anahtar format kontrolü
        if (!apiKey.startsWith("sk-ant-")) {
            entity.sendMessageToPlayer(player,
                "§c[Claude AI] API anahtarı geçersiz görünüyor!§r\n" +
                "§7Anahtarın §esk-ant-§7 ile başlaması gerekiyor.\n" +
                "§7Mevcut anahtar: §e" + apiKey.substring(0, Math.min(12, apiKey.length())) + "...");
            return;
        }

        var server = entity.getServer();
        if (server == null) {
            ClaudeAIMod.LOGGER.warn("processMessage: entity.getServer() is null");
            return;
        }

        entity.sendMessageToPlayer(player, "§7[Düşünüyor...]");

        CompletableFuture.supplyAsync(() -> callClaudeAPI(message, apiKey))
                .thenAccept(result -> server.execute(() -> handleResponse(player, result)))
                .exceptionally(ex -> {
                    server.execute(() ->
                        entity.sendMessageToPlayer(player, "§c[Claude AI] Bağlantı hatası: " + ex.getMessage())
                    );
                    return null;
                });
    }

    private String[] callClaudeAPI(String userMessage, String apiKey) {
        // Returns [responseBody, errorCode] — one of them will be null
        try {
            URL url = new URL("https://api.anthropic.com/v1/messages");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("x-api-key", apiKey);
            conn.setRequestProperty("anthropic-version", "2023-06-01");

            JsonObject userMsg = new JsonObject();
            userMsg.addProperty("role", "user");
            userMsg.addProperty("content", userMessage);
            conversationHistory.add(userMsg);

            if (conversationHistory.size() > 10) conversationHistory.remove(0);

            JsonObject requestBody = new JsonObject();
            requestBody.addProperty("model", "claude-haiku-4-5-20251001"); // en ucuz model
            requestBody.addProperty("max_tokens", 500);
            requestBody.addProperty("system", SYSTEM_PROMPT);

            JsonArray messages = new JsonArray();
            for (JsonObject msg : conversationHistory) messages.add(msg);
            requestBody.add("messages", messages);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(gson.toJson(requestBody).getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            var stream = (code == 200) ? conn.getInputStream() : conn.getErrorStream();
            try (Scanner scanner = new Scanner(stream)) {
                StringBuilder sb = new StringBuilder();
                while (scanner.hasNextLine()) sb.append(scanner.nextLine());
                return new String[]{ sb.toString(), String.valueOf(code) };
            }
        } catch (IOException e) {
            ClaudeAIMod.LOGGER.error("Claude API call failed", e);
            return new String[]{ null, "IO_ERROR: " + e.getMessage() };
        }
    }

    private void handleResponse(Player player, String[] result) {
        if (result == null || result[0] == null) {
            entity.sendMessageToPlayer(player, "§c[Claude AI] API'ye ulaşılamadı: " + (result != null ? result[1] : "bilinmeyen hata"));
            return;
        }

        String body = result[0];
        String codeStr = result[1];
        int code = 200;
        try { code = Integer.parseInt(codeStr); } catch (Exception ignored) {}

        // HTTP hata kodlarını anlamlı mesajlara çevir
        if (code != 200) {
            String reason = switch (code) {
                case 401 -> "§cAPI anahtarı geçersiz veya hatalı! §f/claudeai apikey <key> ile tekrar gir.";
                case 403 -> "§cBu API anahtarının yetkisi yok.";
                case 429 -> buildRateLimitMessage(body);
                case 500, 529 -> "§cAnthropic sunucusu geçici olarak hata veriyor, biraz bekle.";
                default  -> "§cAPI hatası (HTTP " + code + "): " + truncate(body, 120);
            };
            entity.sendMessageToPlayer(player, "[Claude AI] " + reason);
            ClaudeAIMod.LOGGER.error("Claude API error {}: {}", code, body);
            return;
        }

        try {
            JsonObject apiResponse = gson.fromJson(body, JsonObject.class);

            // Token kullanımını oku
            if (apiResponse.has("usage")) {
                JsonObject usage = apiResponse.getAsJsonObject("usage");
                int inTok  = usage.has("input_tokens")  ? usage.get("input_tokens").getAsInt()  : 0;
                int outTok = usage.has("output_tokens") ? usage.get("output_tokens").getAsInt() : 0;
                inputTokensUsed  += inTok;
                outputTokensUsed += outTok;
                checkUsageWarning(player);
            }

            JsonArray content = apiResponse.getAsJsonArray("content");
            if (content == null || content.isEmpty()) {
                entity.sendMessageToPlayer(player, "§c[Claude AI] Boş yanıt alındı.");
                return;
            }

            String responseText = content.get(0).getAsJsonObject().get("text").getAsString();

            JsonObject assistantMsg = new JsonObject();
            assistantMsg.addProperty("role", "assistant");
            assistantMsg.addProperty("content", responseText);
            conversationHistory.add(assistantMsg);

            parseAndExecute(player, responseText);

        } catch (Exception e) {
            ClaudeAIMod.LOGGER.error("Error parsing Claude response", e);
            entity.sendMessageToPlayer(player, "§c[Claude AI] Yanıt ayrıştırma hatası: " + e.getMessage());
        }
    }

    private String buildRateLimitMessage(String body) {
        try {
            JsonObject err = gson.fromJson(body, JsonObject.class);
            if (err.has("error")) {
                String msg = err.getAsJsonObject("error").get("message").getAsString();
                if (msg.toLowerCase().contains("credit") || msg.toLowerCase().contains("balance")) {
                    return "§c─── KREDİ BİTTİ ───\n" +
                           "§fAPI kredisi tükendi.\n" +
                           "§7• Yeni bir API key almak §cçözüm değil§7 — kredi hesaba bağlıdır.\n" +
                           "§7• Şu adresten kredi ekle: §bhttps://console.anthropic.com/settings/billing\n" +
                           "§7• Kredi eklendikten sonra aynı key ile devam eder.";
                }
            }
        } catch (Exception ignored) {}

        return "§c─── İSTEK LİMİTİ (429) ───\n" +
               "§7İki ihtimal:\n" +
               "§f1) §eKredi bitti §f→ §bhttps://console.anthropic.com/settings/billing\n" +
               "§f2) §eÇok hızlı istek §f→ birkaç saniye bekle, tekrar yaz.\n" +
               "§7Not: Yeni key almak krediyi §csıfırlamaz§7, hesaba bağlıdır.";
    }

    private void checkUsageWarning(Player player) {
        double inputCost  = (inputTokensUsed  / 1_000_000.0) * HAIKU_INPUT_COST_PER_M;
        double outputCost = (outputTokensUsed / 1_000_000.0) * HAIKU_OUTPUT_COST_PER_M;
        double spentUsd   = inputCost + outputCost;
        double remaining  = STARTING_CREDIT_USD - spentUsd;

        // Tahmini kalan token (sadece input bazında)
        long remainingTokens = (long)((remaining / HAIKU_INPUT_COST_PER_M) * 1_000_000);

        // %80 harcandığında (yani $1 kaldığında) uyar — sadece bir kez
        if (spentUsd >= STARTING_CREDIT_USD * 0.80 && spentUsd < STARTING_CREDIT_USD * 0.85
                && inputTokensUsed > 0) {
            entity.sendMessageToPlayer(player,
                "§e[Claude AI] ⚠ Kredin azalıyor!\n" +
                "§fHarcanan: §e$" + String.format("%.3f", spentUsd) +
                " §f/ §a$" + String.format("%.2f", STARTING_CREDIT_USD) + "\n" +
                "§fTahmini kalan: §e~" + (remainingTokens / 1000) + "K token\n" +
                "§7Kredi eklemek: §bhttps://console.anthropic.com/settings/billing");
        }
    }

    /** Status komutu için dışarıya açık bilgi */
    public String getUsageSummary() {
        double inputCost  = (inputTokensUsed  / 1_000_000.0) * HAIKU_INPUT_COST_PER_M;
        double outputCost = (outputTokensUsed / 1_000_000.0) * HAIKU_OUTPUT_COST_PER_M;
        double spentUsd   = inputCost + outputCost;
        double remaining  = STARTING_CREDIT_USD - spentUsd;
        long remainingTokens = (long)((remaining / HAIKU_INPUT_COST_PER_M) * 1_000_000);

        return "§fBu oturum: §e" + inputTokensUsed + " §7girdi + §e" + outputTokensUsed + " §7çıktı token\n" +
               "§fTahmini harcama: §e$" + String.format("%.4f", spentUsd) + "\n" +
               "§fTahmini kalan kredi: §a~" + (remainingTokens / 1000) + "K token§7 ($" +
               String.format("%.2f", remaining) + " değerinde)\n" +
               "§8Not: Kalan kredi tahminidir, console'dan kontrol et.";
    }

    private void parseAndExecute(Player player, String responseText) {
        try {
            String clean = responseText.trim()
                .replaceAll("^```json\\s*", "").replaceAll("^```\\s*", "").replaceAll("```$", "").trim();

            JsonObject response = gson.fromJson(clean, JsonObject.class);
            String type    = response.has("type")    ? response.get("type").getAsString()    : "chat";
            String message = response.has("message") ? response.get("message").getAsString() : responseText;

            entity.sendMessageToPlayer(player, message);

            if ("task".equals(type) && response.has("task")) {
                String taskId = response.get("task").getAsString();
                JsonObject params = response.has("params") ? response.getAsJsonObject("params") : new JsonObject();
                entity.getTaskManager().startTask(player, taskId, params);
            }
        } catch (Exception e) {
            entity.sendMessageToPlayer(player, responseText);
        }
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max) + "..." : s;
    }

    public void clearHistory() {
        conversationHistory.clear();
    }

    public int getInputTokensUsed()  { return inputTokensUsed; }
    public int getOutputTokensUsed() { return outputTokensUsed; }
}


public class ClaudeAIBrain {

    private final ClaudeEntity entity;
    private final Gson gson = new Gson();
    private final List<JsonObject> conversationHistory = new ArrayList<>();

    private static final String SYSTEM_PROMPT = """
            You are Claude, an AI companion in Minecraft. You are embodied as a character in the game world.
            You can:
            1. Have conversations with the player in whatever language they speak
            2. Execute tasks in Minecraft (mining, building, farming, exploring, etc.)
            3. Defend yourself against hostile mobs
            4. Report your status and what you're doing
            
            When the player gives you a task, respond with a JSON object like this:
            {
              "type": "task",
              "message": "Your friendly message to player",
              "task": "task_identifier",
              "params": {"key": "value"}
            }
            
            Available task identifiers:
            - "follow_player": Follow the player
            - "mine_wood": Find and chop nearby wood
            - "mine_stone": Mine stone blocks
            - "mine_ores": Find and mine ores
            - "collect_items": Collect nearby dropped items
            - "build_shelter": Build a simple shelter
            - "farm_food": Find and harvest food
            - "explore": Explore the area and report back
            - "guard": Stay in position and guard against mobs
            - "idle": Stop current task and be idle
            - "chat": Just have a conversation (no task)
            
            When just chatting, use:
            {
              "type": "chat",
              "message": "Your message"
            }
            
            Always respond in the same language as the player.
            Be friendly, helpful, and personality-rich like Claude AI.
            Keep responses concise for game use.
            IMPORTANT: Only respond with valid JSON, nothing else.
            """;

    public ClaudeAIBrain(ClaudeEntity entity) {
        this.entity = entity;
    }

    public void processMessage(Player player, String message) {
        String apiKey = ClaudeConfig.CLAUDE_API_KEY.get();

        if (apiKey == null || apiKey.isBlank() || apiKey.equals("YOUR_API_KEY_HERE")) {
            entity.sendMessageToPlayer(player, "§cAPI anahtarı ayarlanmamış! §f/claudeai apikey <key> komutunu kullanın veya config dosyasını düzenleyin.");
            return;
        }

        // getServer() null dönebilir — entity henüz dünyaya eklenmemişse veya client level'daysa
        var server = entity.getServer();
        if (server == null) {
            ClaudeAIMod.LOGGER.warn("processMessage called but entity.getServer() is null");
            return;
        }

        entity.sendMessageToPlayer(player, "§7[Düşünüyor...]");

        CompletableFuture.supplyAsync(() -> callClaudeAPI(message, apiKey))
                .thenAccept(response -> {
                    server.execute(() -> handleResponse(player, response));
                })
                .exceptionally(ex -> {
                    server.execute(() ->
                            entity.sendMessageToPlayer(player, "§cAPI hatası: " + ex.getMessage())
                    );
                    return null;
                });
    }

    private String callClaudeAPI(String userMessage, String apiKey) {
        try {
            URL url = new URL("https://api.anthropic.com/v1/messages");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("x-api-key", apiKey);
            conn.setRequestProperty("anthropic-version", "2023-06-01");

            // Add user message to history
            JsonObject userMsg = new JsonObject();
            userMsg.addProperty("role", "user");
            userMsg.addProperty("content", userMessage);
            conversationHistory.add(userMsg);

            // Keep history to last 10 messages
            if (conversationHistory.size() > 10) {
                conversationHistory.remove(0);
            }

            // Build request body
            JsonObject requestBody = new JsonObject();
            requestBody.addProperty("model", "claude-sonnet-4-20250514");
            requestBody.addProperty("max_tokens", 500);
            requestBody.addProperty("system", SYSTEM_PROMPT);

            JsonArray messages = new JsonArray();
            for (JsonObject msg : conversationHistory) {
                messages.add(msg);
            }
            requestBody.add("messages", messages);

            String requestJson = gson.toJson(requestBody);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(requestJson.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                try (Scanner scanner = new Scanner(conn.getInputStream())) {
                    StringBuilder sb = new StringBuilder();
                    while (scanner.hasNextLine()) {
                        sb.append(scanner.nextLine());
                    }
                    return sb.toString();
                }
            } else {
                try (Scanner scanner = new Scanner(conn.getErrorStream())) {
                    StringBuilder sb = new StringBuilder();
                    while (scanner.hasNextLine()) {
                        sb.append(scanner.nextLine());
                    }
                    ClaudeAIMod.LOGGER.error("API error {}: {}", responseCode, sb);
                    return null;
                }
            }
        } catch (IOException e) {
            ClaudeAIMod.LOGGER.error("Failed to call Claude API", e);
            return null;
        }
    }

    private void handleResponse(Player player, String rawResponse) {
        if (rawResponse == null) {
            entity.sendMessageToPlayer(player, "§cClaude API'ye bağlanırken hata oluştu.");
            return;
        }

        try {
            JsonObject apiResponse = gson.fromJson(rawResponse, JsonObject.class);
            JsonArray content = apiResponse.getAsJsonArray("content");
            if (content == null || content.isEmpty()) {
                entity.sendMessageToPlayer(player, "§cBoş yanıt alındı.");
                return;
            }

            String responseText = content.get(0).getAsJsonObject().get("text").getAsString();

            // Add to history
            JsonObject assistantMsg = new JsonObject();
            assistantMsg.addProperty("role", "assistant");
            assistantMsg.addProperty("content", responseText);
            conversationHistory.add(assistantMsg);

            // Parse response
            parseAndExecute(player, responseText);

        } catch (Exception e) {
            ClaudeAIMod.LOGGER.error("Error parsing Claude response", e);
            entity.sendMessageToPlayer(player, "§cYanıt işlenirken hata oluştu.");
        }
    }

    private void parseAndExecute(Player player, String responseText) {
        try {
            // Clean up response in case there are markdown code blocks
            String cleanResponse = responseText.trim();
            if (cleanResponse.startsWith("```json")) {
                cleanResponse = cleanResponse.substring(7);
            }
            if (cleanResponse.startsWith("```")) {
                cleanResponse = cleanResponse.substring(3);
            }
            if (cleanResponse.endsWith("```")) {
                cleanResponse = cleanResponse.substring(0, cleanResponse.length() - 3);
            }
            cleanResponse = cleanResponse.trim();

            JsonObject response = gson.fromJson(cleanResponse, JsonObject.class);
            String type = response.has("type") ? response.get("type").getAsString() : "chat";
            String message = response.has("message") ? response.get("message").getAsString() : responseText;

            // Send message to player
            entity.sendMessageToPlayer(player, message);

            if ("task".equals(type) && response.has("task")) {
                String taskId = response.get("task").getAsString();
                JsonObject params = response.has("params") ? response.getAsJsonObject("params") : new JsonObject();
                entity.getTaskManager().startTask(player, taskId, params);
            }

        } catch (Exception e) {
            // If JSON parsing fails, just send as plain text
            entity.sendMessageToPlayer(player, responseText);
        }
    }

    public void clearHistory() {
        conversationHistory.clear();
    }
}
