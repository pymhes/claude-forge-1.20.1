package com.claudeai.mod.ai;

import com.claudeai.mod.ClaudeAIMod;
import com.claudeai.mod.config.ClaudeConfig;
import com.claudeai.mod.entity.ClaudeEntity;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.world.entity.player.Player;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.CompletableFuture;

public class ClaudeAIBrain {

    private final ClaudeEntity entity;
    private final Gson gson = new Gson();
    private final List<JsonObject> conversationHistory = new ArrayList<>();

    private static final String SYSTEM_PROMPT = """
            You are Claude, an AI companion in Minecraft. You are embodied as a character in the game world.
            You can:
            1. Have conversations with the player in whatever language they speak
            2. Execute tasks in Minecraft (mining, building, farming, exploring, etc.)
            3. Defend yourself against hostile mobs
            4. Report your status and what you're doing
            
            When the player gives you a task, respond with a JSON object like this:
            {
              "type": "task",
              "message": "Your friendly message to player",
              "task": "task_identifier",
              "params": {"key": "value"}
            }
            
            Available task identifiers:
            - "follow_player": Follow the player
            - "mine_wood": Find and chop nearby wood
            - "mine_stone": Mine stone blocks
            - "mine_ores": Find and mine ores
            - "collect_items": Collect nearby dropped items
            - "build_shelter": Build a simple shelter
            - "farm_food": Find and harvest food
            - "explore": Explore the area and report back
            - "guard": Stay in position and guard against mobs
            - "idle": Stop current task and be idle
            - "chat": Just have a conversation (no task)
            
            When just chatting, use:
            {
              "type": "chat",
              "message": "Your message"
            }
            
            Always respond in the same language as the player.
            Be friendly, helpful, and personality-rich like Claude AI.
            Keep responses concise for game use.
            IMPORTANT: Only respond with valid JSON, nothing else.
            """;

    public ClaudeAIBrain(ClaudeEntity entity) {
        this.entity = entity;
    }

    public void processMessage(Player player, String message) {
        String apiKey = ClaudeConfig.CLAUDE_API_KEY.get();

        if (apiKey == null || apiKey.isBlank() || apiKey.equals("YOUR_API_KEY_HERE")) {
            entity.sendMessageToPlayer(player, "§cAPI anahtarı ayarlanmamış! §f/claudeai apikey <key> komutunu kullanın veya config dosyasını düzenleyin.");
            return;
        }

        // getServer() null dönebilir — entity henüz dünyaya eklenmemişse veya client level'daysa
        var server = entity.getServer();
        if (server == null) {
            ClaudeAIMod.LOGGER.warn("processMessage called but entity.getServer() is null");
            return;
        }

        entity.sendMessageToPlayer(player, "§7[Düşünüyor...]");

        CompletableFuture.supplyAsync(() -> callClaudeAPI(message, apiKey))
                .thenAccept(response -> {
                    server.execute(() -> handleResponse(player, response));
                })
                .exceptionally(ex -> {
                    server.execute(() ->
                            entity.sendMessageToPlayer(player, "§cAPI hatası: " + ex.getMessage())
                    );
                    return null;
                });
    }

    private String callClaudeAPI(String userMessage, String apiKey) {
        try {
            URL url = new URL("https://api.anthropic.com/v1/messages");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("x-api-key", apiKey);
            conn.setRequestProperty("anthropic-version", "2023-06-01");

            // Add user message to history
            JsonObject userMsg = new JsonObject();
            userMsg.addProperty("role", "user");
            userMsg.addProperty("content", userMessage);
            conversationHistory.add(userMsg);

            // Keep history to last 10 messages
            if (conversationHistory.size() > 10) {
                conversationHistory.remove(0);
            }

            // Build request body
            JsonObject requestBody = new JsonObject();
            requestBody.addProperty("model", "claude-sonnet-4-20250514");
            requestBody.addProperty("max_tokens", 500);
            requestBody.addProperty("system", SYSTEM_PROMPT);

            JsonArray messages = new JsonArray();
            for (JsonObject msg : conversationHistory) {
                messages.add(msg);
            }
            requestBody.add("messages", messages);

            String requestJson = gson.toJson(requestBody);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(requestJson.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                try (Scanner scanner = new Scanner(conn.getInputStream())) {
                    StringBuilder sb = new StringBuilder();
                    while (scanner.hasNextLine()) {
                        sb.append(scanner.nextLine());
                    }
                    return sb.toString();
                }
            } else {
                try (Scanner scanner = new Scanner(conn.getErrorStream())) {
                    StringBuilder sb = new StringBuilder();
                    while (scanner.hasNextLine()) {
                        sb.append(scanner.nextLine());
                    }
                    ClaudeAIMod.LOGGER.error("API error {}: {}", responseCode, sb);
                    return null;
                }
            }
        } catch (IOException e) {
            ClaudeAIMod.LOGGER.error("Failed to call Claude API", e);
            return null;
        }
    }

    private void handleResponse(Player player, String rawResponse) {
        if (rawResponse == null) {
            entity.sendMessageToPlayer(player, "§cClaude API'ye bağlanırken hata oluştu.");
            return;
        }

        try {
            JsonObject apiResponse = gson.fromJson(rawResponse, JsonObject.class);
            JsonArray content = apiResponse.getAsJsonArray("content");
            if (content == null || content.isEmpty()) {
                entity.sendMessageToPlayer(player, "§cBoş yanıt alındı.");
                return;
            }

            String responseText = content.get(0).getAsJsonObject().get("text").getAsString();

            // Add to history
            JsonObject assistantMsg = new JsonObject();
            assistantMsg.addProperty("role", "assistant");
            assistantMsg.addProperty("content", responseText);
            conversationHistory.add(assistantMsg);

            // Parse response
            parseAndExecute(player, responseText);

        } catch (Exception e) {
            ClaudeAIMod.LOGGER.error("Error parsing Claude response", e);
            entity.sendMessageToPlayer(player, "§cYanıt işlenirken hata oluştu.");
        }
    }

    private void parseAndExecute(Player player, String responseText) {
        try {
            // Clean up response in case there are markdown code blocks
            String cleanResponse = responseText.trim();
            if (cleanResponse.startsWith("```json")) {
                cleanResponse = cleanResponse.substring(7);
            }
            if (cleanResponse.startsWith("```")) {
                cleanResponse = cleanResponse.substring(3);
            }
            if (cleanResponse.endsWith("```")) {
                cleanResponse = cleanResponse.substring(0, cleanResponse.length() - 3);
            }
            cleanResponse = cleanResponse.trim();

            JsonObject response = gson.fromJson(cleanResponse, JsonObject.class);
            String type = response.has("type") ? response.get("type").getAsString() : "chat";
            String message = response.has("message") ? response.get("message").getAsString() : responseText;

            // Send message to player
            entity.sendMessageToPlayer(player, message);

            if ("task".equals(type) && response.has("task")) {
                String taskId = response.get("task").getAsString();
                JsonObject params = response.has("params") ? response.getAsJsonObject("params") : new JsonObject();
                entity.getTaskManager().startTask(player, taskId, params);
            }

        } catch (Exception e) {
            // If JSON parsing fails, just send as plain text
            entity.sendMessageToPlayer(player, responseText);
        }
    }

    public void clearHistory() {
        conversationHistory.clear();
    }
}
