package com.claudeai.mod;

import com.claudeai.mod.client.ClaudeEntityModel;
import com.claudeai.mod.client.ClaudeEntityRenderer;
import com.claudeai.mod.entity.ClaudeEntity;
import com.claudeai.mod.entity.ModEntities;
import com.claudeai.mod.network.ModNetwork;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(ClaudeAIMod.MOD_ID)
public class ClaudeAIMod {
    public static final String MOD_ID = "claudeai";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public ClaudeAIMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModEntities.ENTITY_TYPES.register(modEventBus);

        // Tüm event'ler modEventBus'a addListener ile kayıt edildi.
        // MinecraftForge.EVENT_BUS.register(this) KALDIRILDI — @SubscribeEvent
        // ile onEntityAttributeCreation'ın çift kayıt olmasını önler.
        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::onEntityAttributeCreation);
        modEventBus.addListener(this::onRegisterRenderers);
        modEventBus.addListener(this::onRegisterLayerDefinitions);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ClaudeConfig.SPEC, "claudeai-common.toml");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        ModNetwork.register();
        LOGGER.info("Claude AI Mod loaded successfully!");
    }

    // @SubscribeEvent KALDIRILDI — addListener zaten modEventBus'a kayıt ediyor.
    // İkisi birden olsaydı event iki kez fire olur, attributes duplicate hatası verirdi.
    private void onEntityAttributeCreation(EntityAttributeCreationEvent event) {
        event.put(ModEntities.CLAUDE_ENTITY.get(), ClaudeEntity.createAttributes().build());
    }

    private void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.CLAUDE_ENTITY.get(), ClaudeEntityRenderer::new);
    }

    private void onRegisterLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(ClaudeEntityRenderer.LAYER_LOCATION, ClaudeEntityModel::createBodyLayer);
    }
}
