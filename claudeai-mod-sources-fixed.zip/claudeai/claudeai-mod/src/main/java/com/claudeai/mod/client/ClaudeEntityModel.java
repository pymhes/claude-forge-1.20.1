package com.claudeai.mod.client;

import com.claudeai.mod.entity.ClaudeEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;

public class ClaudeEntityModel extends HumanoidModel<ClaudeEntity> {

    public ClaudeEntityModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(new CubeDeformations(0.0F), 0.0F);
        return LayerDefinition.create(mesh, 64, 64);
    }
}
