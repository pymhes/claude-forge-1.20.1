package com.claudeai.mod;

import com.claudeai.mod.config.ClaudeConfig;
import com.claudeai.mod.entity.ClaudeEntity;
import com.claudeai.mod.entity.ModEntities;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ClaudeAIMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClaudeCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("claudeai")
                        .then(Commands.literal("spawn")
                                .requires(src -> src.hasPermission(0))
                                .executes(ctx -> spawnClaude(ctx.getSource())))
                        .then(Commands.literal("apikey")
                                .requires(src -> src.hasPermission(2))
                                .then(Commands.argument("key", StringArgumentType.string())
                                        .executes(ctx -> setApiKey(ctx.getSource(),
                                                StringArgumentType.getString(ctx, "key")))))
                        .then(Commands.literal("status")
                                .requires(src -> src.hasPermission(0))
                                .executes(ctx -> showStatus(ctx.getSource())))
                        .then(Commands.literal("help")
                                .requires(src -> src.hasPermission(0))
                                .executes(ctx -> showHelp(ctx.getSource())))
        );
    }

    private static int spawnClaude(CommandSourceStack source) {
        try {
            ServerPlayer player = source.getPlayerOrException();
            ServerLevel level = source.getLevel();

            Vec3 pos = player.position().add(2, 0, 0);
            ClaudeEntity claude = ModEntities.CLAUDE_ENTITY.get().create(level);

            if (claude != null) {
                claude.setPos(pos.x, pos.y, pos.z);
                claude.setOwner(player);
                level.addFreshEntity(claude);

                source.sendSuccess(() -> Component.literal(
                        "§b[Claude AI] §fClaude oluşturuldu! Sana yakın bir yerde belirdi. Chat'e yazarak konuşabilirsin."
                ), false);
            }
        } catch (Exception e) {
            source.sendFailure(Component.literal("§cClaude oluşturulamadı: " + e.getMessage()));
        }
        return 1;
    }

    private static int setApiKey(CommandSourceStack source, String key) {
        ClaudeConfig.CLAUDE_API_KEY.set(key);
        // .save() ForgeConfigSpec'te yok, config dosyasına yazmak için spec.save() kullanılır
        ClaudeConfig.SPEC.save();
        source.sendSuccess(() -> Component.literal(
                "§b[Claude AI] §fAPI anahtarı ayarlandı! Artık Claude ile konuşabilirsiniz."
        ), false);
        ClaudeAIMod.LOGGER.info("Claude API key updated");
        return 1;
    }

    private static int showStatus(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal(
                "§b=== Claude AI Durumu ===\n" +
                        "§fMod: §aAktif\n" +
                        "§fAPI Anahtarı: " +
                        (ClaudeConfig.CLAUDE_API_KEY.get().equals("YOUR_API_KEY_HERE") ?
                                "§cAyarlanmamış" : "§aAyarlanmış") + "\n" +
                        "§fOtomatik Savunma: " +
                        (ClaudeConfig.AUTO_DEFEND.get() ? "§aAktif" : "§cDeaktif") + "\n" +
                        "§fSohbet Yarıçapı: §e" + ClaudeConfig.CHAT_RADIUS.get() + " blok"
        ), false);
        return 1;
    }

    private static int showHelp(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal(
                "§b=== Claude AI Yardım ===\n" +
                        "§e/claudeai spawn §f- Claude'u yanına çağır\n" +
                        "§e/claudeai apikey <anahtar> §f- API anahtarını ayarla\n" +
                        "§e/claudeai status §f- Mod durumunu göster\n\n" +
                        "§b=== Kullanım ===\n" +
                        "§fClaude'u oluşturduktan sonra chat'e yaz:\n" +
                        "§7• 'Ağaç kes'\n" +
                        "§7• 'Maden ara'\n" +
                        "§7• 'Eşyaları topla'\n" +
                        "§7• 'Beni koru'\n" +
                        "§7• 'Keşfet'\n" +
                        "§7• Ya da herhangi bir şeyi sor/söyle!"
        ), false);
        return 1;
    }
}
