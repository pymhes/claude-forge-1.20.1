package com.claudeai.mod.entity;

import com.claudeai.mod.ai.ClaudeAIBrain;
import com.claudeai.mod.ai.TaskManager;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;

import javax.annotation.Nullable;
import java.util.UUID;

public class ClaudeEntity extends PathfinderMob {

    private static final EntityDataAccessor<String> STATUS_MESSAGE =
            SynchedEntityData.defineId(ClaudeEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> IS_BUSY =
            SynchedEntityData.defineId(ClaudeEntity.class, EntityDataSerializers.BOOLEAN);

    private ClaudeAIBrain claudeBrain;
    private TaskManager taskManager;
    private UUID ownerUUID;
    private String ownerName = "";
    private int thinkTimer = 0;
    private String currentTask = "";
    private boolean defending = false;

    public ClaudeEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.0F);
        this.claudeBrain = new ClaudeAIBrain(this);
        this.taskManager = new TaskManager(this);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.35D)
                .add(Attributes.ATTACK_DAMAGE, 5.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.ARMOR, 2.0D)
                .add(ForgeMod.ENTITY_GRAVITY.get(), 0.08D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATUS_MESSAGE, "");
        this.entityData.define(IS_BUSY, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2D, false));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(0, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, true, false));
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide) {
            thinkTimer++;
            if (thinkTimer >= 20) {
                thinkTimer = 0;
                taskManager.tick();
            }

            // Check for nearby threats and defend
            checkAndDefend();
        }
    }

    private void checkAndDefend() {
        if (this.getTarget() != null) {
            this.defending = true;
            if (!currentTask.isEmpty()) {
                sendMessageToOwner("§c[Savunma] Saldırıya uğradım, göreve devam etmeden önce kendimi savunuyorum!");
            }
        } else {
            if (this.defending) {
                this.defending = false;
                if (!currentTask.isEmpty()) {
                    sendMessageToOwner("§a[Savunma] Tehlike geçti, göreve devam ediyorum: " + currentTask);
                }
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (this.level().isClientSide) return InteractionResult.SUCCESS;

        ItemStack itemInHand = player.getItemInHand(hand);

        if (itemInHand.getItem() == Items.BOOK || itemInHand.getItem() == Items.WRITABLE_BOOK) {
            // Open config screen
            player.sendSystemMessage(Component.literal("§b[Claude AI] §fAPI anahtarınızı ayarlamak için /claudeai apikey <key> komutunu kullanın."));
            return InteractionResult.SUCCESS;
        }

        // Show status
        player.sendSystemMessage(Component.literal("§b[Claude AI] §fMerhaba! Ben Claude. Chat'e yazarak benimle konuşabilirsin!"));
        if (!currentTask.isEmpty()) {
            player.sendSystemMessage(Component.literal("§b[Claude AI] §fŞu an şunu yapıyorum: §e" + currentTask));
        } else {
            player.sendSystemMessage(Component.literal("§b[Claude AI] §fŞu an boştayım, bana bir görev verebilirsin!"));
        }

        return InteractionResult.SUCCESS;
    }

    public void receivePlayerMessage(Player player, String message) {
        // getServer() client-side'da null döner, sadece server'da çalıştır
        if (this.level().isClientSide) return;

        if (ownerUUID == null) {
            setOwner(player);
        }

        if (!player.getUUID().equals(ownerUUID) && ownerUUID != null) {
            player.sendSystemMessage(Component.literal("§b[Claude AI] §fBen " + ownerName + " adlı oyuncunun AI arkadaşıyım, ama sana da yardım edebilirim!"));
        }

        claudeBrain.processMessage(player, message);
    }

    public void setOwner(Player player) {
        this.ownerUUID = player.getUUID();
        this.ownerName = player.getName().getString();
        player.sendSystemMessage(Component.literal("§b[Claude AI] §fArtık senin AI arkadaşınım, " + ownerName + "! Chat'e yazarak benimle konuşabilirsin."));
    }

    public void sendMessageToOwner(String message) {
        if (this.level().isClientSide) return;
        Player owner = findOwner();
        if (owner != null) {
            owner.sendSystemMessage(Component.literal("§b[Claude AI] §f" + message));
        }
    }

    public void sendMessageToPlayer(Player player, String message) {
        if (!this.level().isClientSide) {
            player.sendSystemMessage(Component.literal("§b[Claude AI] §f" + message));
        }
    }

    @Nullable
    public Player findOwner() {
        if (ownerUUID == null) return null;
        return this.level().getPlayerByUUID(ownerUUID);
    }

    public void setCurrentTask(String task) {
        this.currentTask = task;
        this.entityData.set(IS_BUSY, !task.isEmpty());
    }

    public String getCurrentTask() {
        return currentTask;
    }

    public boolean isBusy() {
        return this.entityData.get(IS_BUSY);
    }

    public TaskManager getTaskManager() {
        return taskManager;
    }

    public ClaudeAIBrain getClaudeBrain() {
        return claudeBrain;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerUUID != null) {
            tag.putUUID("OwnerUUID", ownerUUID);
        }
        tag.putString("OwnerName", ownerName);
        tag.putString("CurrentTask", currentTask);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("OwnerUUID")) {
            ownerUUID = tag.getUUID("OwnerUUID");
        }
        ownerName = tag.getString("OwnerName");
        currentTask = tag.getString("CurrentTask");
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && source.getEntity() instanceof LivingEntity attacker) {
            this.setTarget(attacker);
            sendMessageToOwner("§c[Uyarı] Saldırıya uğradım! Kendimi savunuyorum!");
        }
        return result;
    }

    @Override
    public boolean removeWhenFarAway(double dist) {
        return false;
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    public UUID getOwnerUUID() {
        return ownerUUID;
    }

    // Custom goal to follow owner
    private class FollowOwnerGoal extends Goal {
        private final ClaudeEntity entity;
        private Player owner;
        private int timeToRecalc;

        public FollowOwnerGoal(ClaudeEntity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canUse() {
            Player owner = entity.findOwner();
            if (owner == null) return false;
            if (entity.isBusy()) return false;
            double dist = entity.distanceToSqr(owner);
            return dist > 16.0D;
        }

        @Override
        public void start() {
            this.timeToRecalc = 0;
            owner = entity.findOwner();
        }

        @Override
        public void tick() {
            if (owner == null) return;
            if (--this.timeToRecalc <= 0) {
                this.timeToRecalc = 10;
                entity.getNavigation().moveTo(owner, 1.0D);
            }
        }

        @Override
        public boolean canContinueToUse() {
            if (entity.isBusy()) return false;
            Player owner = entity.findOwner();
            if (owner == null) return false;
            return entity.distanceToSqr(owner) > 9.0D;
        }
    }
}
